from Crypto.PublicKey import RSA

def decrypt_raw_rsa(privkey_path, ciphertext_path):
    # 1. Doc khoa rieng
    with open(privkey_path, "rb") as f:
        key = RSA.import_key(f.read())

    d = key.d
    n = key.n

    # 2. Doc ciphertext va chuyen thanh so nguyen
    with open(ciphertext_path, "rb") as f:
        c = int.from_bytes(f.read(), byteorder='big')

    # 3. Cong thuc giai ma RSA:

    # 4. Chuyen ve dang chuoi 
    plaintext_bytes = m.to_bytes((m.bit_length() + 7) // 8, byteorder='big')
    
    try:
        plaintext = plaintext_bytes.decode()
    except UnicodeDecodeError:
        plaintext = plaintext_bytes.decode(errors='ignore')

    print("[+] Plaintext:", plaintext)

    # Ghi ra file
    with open("plaintext.txt", "wb") as f:
        f.write(plaintext_bytes)

#Dien cac file can dung vao day
if __name__ == "__main__":
    decrypt_raw_rsa("/path", "/path")
