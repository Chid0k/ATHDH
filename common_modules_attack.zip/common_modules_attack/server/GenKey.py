from Crypto.PublicKey import RSA
from Crypto.Util.number import getPrime, inverse, GCD, bytes_to_long, long_to_bytes
from Crypto.Random import get_random_bytes

def generate_common_modulus_rsa(bits=1024, d_bit_limit=128):
    # Sinh chung p, q, n, phi
    p = getPrime(bits // 2)
    q = getPrime(bits // 2)
    n = p * q
    phi = (p - 1) * (q - 1)

    # Sinh d1 và e1 (cho victim)
    while True:
        d1 = getPrime(d_bit_limit)
        if GCD(d1, phi) == 1:
            try:
                e1 = inverse(d1, phi)
                break
            except ValueError:
                continue

    # Sinh d2 và e2 (cho attacker)
    while True:
        d2 = getPrime(d_bit_limit)
        if GCD(d2, phi) == 1 and d2 != d1:
            try:
                e2 = inverse(d2, phi)
                break
            except ValueError:
                continue

    # Tao cac doi tuong key
    victim_key = RSA.construct((n, e1, d1, p, q))
    attacker_key = RSA.construct((n, e2, d2, p, q))

    # Export key
    with open("victim_private.pem", "wb") as f:
        f.write(victim_key.export_key())
    with open("victim_public.pem", "wb") as f:
        f.write(victim_key.publickey().export_key())

    with open("attacker_private.pem", "wb") as f:
        f.write(attacker_key.export_key())
    with open("attacker_public.pem", "wb") as f:
        f.write(attacker_key.publickey().export_key())

    print("[+] Tao thanh cong 2 cap khoa [+]")

if __name__ == "__main__":
    generate_common_modulus_rsa()

