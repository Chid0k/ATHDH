from Crypto.PublicKey import RSA

def encrypt_raw_rsa(pubkey_path, message, output_path):
    # 1. Đọc khóa công khai
    with open(pubkey_path, "rb") as f:
        key = RSA.import_key(f.read())

    e = key.e
    n = key.n

    # 2. Chuyển thông điệp thành số nguyên
    m = int.from_bytes(message.encode(), byteorder='big')
    if m >= n:
        raise ValueError("Thong diep qua lon so voi modulus n.")

    # 3. Mã hóa thủ công: 

    # 4. Ghi ciphertext vào file
    with open(output_path, "wb") as f:
        f.write(c.to_bytes((n.bit_length() + 7) // 8, byteorder='big'))

    print("[+] Thong diep duoc ma hoa va luu tai:", output_path)

#Điền các file 
if __name__ == "__main__":
    message = input("Nhap thong diep can ma hoa: ")
    encrypt_raw_rsa("/path", message, "ciphertext.bin")
