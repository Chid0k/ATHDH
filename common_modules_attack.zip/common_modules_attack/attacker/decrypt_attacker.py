from Crypto.PublicKey import RSA

def decrypt_raw_rsa_with_d(pubkey_path, d_path, ciphertext_path):
    # 1. Doc khoa cong khai de lay n
    with open(pubkey_path, "rb") as f:
        key = RSA.import_key(f.read())
    n = key.n

    # 2. Doc gia tri d tu file
    with open(d_path, "r") as f:
        d_str = f.read().strip()
    d = int(d_str)
    
    # 3. Doc ciphertext va chuyen thanh dang so nguyen
    with open(ciphertext_path, "rb") as f:
        c = int.from_bytes(f.read(), byteorder='big')

    # 4. Cong thuc giai ma RSA: 

    # 5. Chuyen ket qua ve bytes va  decode
    plaintext_bytes = m.to_bytes((m.bit_length() + 7) // 8, byteorder='big')
    
    try:
        plaintext = plaintext_bytes.decode()
    except UnicodeDecodeError:
        plaintext = plaintext_bytes.decode(errors='ignore')

    print("[+] Plaintext:", plaintext)

    # Ghi ra file
    with open("plaintext_attack.txt", "wb") as f:
        f.write(plaintext_bytes)

#Dien cac file can dung vao day
if __name__ == "__main__":
    decrypt_raw_rsa_with_d("/path", "/path", "/path")
