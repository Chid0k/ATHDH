from Crypto.PublicKey import RSA
from Crypto.Util.number import *

def extended_gcd(a, b):
    #Code thuat toan Euclid mo rong

def recover_d1(e1, e2, d2):
    #Tim d1 


if __name__ == "__main__":
    # Doc khoa cong khai cua victim
    victim_key = RSA.import_key(open("victim_public.pem", "rb").read())
    e1 = victim_key.e  

    # Doc khoa cong khai cua attacker
    attacker_key = RSA.import_key(open("attacker_public.pem", "rb").read())
    e2 = attacker_key.e  
    
    # Doc khoa bi mat cua attacker
    attacker_key = RSA.import_key(open("attacker_private.pem", "rb").read())
    d2 = attacker_key.d 

    d1 = recover_d1(e1, e2, d2)
    print("[+] Khoa bi mat d1:", d1)

  # Luu d1 duoi dang so
    with open("victim_d1.txt", "w") as f:
        f.write(str(d1))
